# ft_package

## Description

This package provides a simple utility function: `count_in_list`.

## Function

```python
def count_in_list(lst: list, item: str) -> int:
